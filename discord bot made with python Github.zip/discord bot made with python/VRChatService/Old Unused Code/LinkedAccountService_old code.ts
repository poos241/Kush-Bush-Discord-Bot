import fs from "fs";
import path from "path";

const FILE = path.join(__dirname, "../data/linked_accounts.json");

export interface LinkedAccount {

    discordId: string;

    vrchatId: string;

    displayName: string;

    linked: boolean;

    friendAdded: boolean;

    groupInvited: boolean;

    groupJoined: boolean;

    discordRoleGiven: boolean;

    created: number;

    updated: number;

}

function load(): LinkedAccount[] {

    if (!fs.existsSync(FILE))
        return [];

    return JSON.parse(fs.readFileSync(FILE, "utf8"));

}

function save(accounts: LinkedAccount[]) {

    fs.writeFileSync(
        FILE,
        JSON.stringify(accounts, null, 4)
    );

}



export default {

    get(discordId: string) {

        return load().find(x => x.discordId == discordId);

    },

    exists(discordId: string) {

        return this.get(discordId) != undefined;

    },

    

    add(account: LinkedAccount) {

        const accounts = load();

        accounts.push(account);

        save(accounts);

    },

    update(account: LinkedAccount) {

        const accounts = load();

        const index = accounts.findIndex(
            x => x.discordId == account.discordId
        );

        if (index != -1) {

            accounts[index] = account;

            save(accounts);

        }

    },

    setFriendAdded(discordId: string) {

        const account = this.get(discordId);

        if (!account)
            return;

        account.friendAdded = true;

        account.updated = Date.now();

        this.update(account);

        }

}